//This is the implementation of the EmployeeDao interface. The methods are overridden to perform database operations and return appropriate results. 

package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import com.cg.ems.util.QueryMapper;
/*
 * In the EmployeeDaoImpl class the Connection object is defined which establishes the connection by calling DBUtil class.
 * Statement, Prepared Statements are also defined to perform various database operations.
 * ResultSet is used to store the fetch operations.
 * Logger is defined to log the entire process in a log file. 
 */
public class EmployeeDaoImpl implements EmployeeDao {
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Logger emsLogger = null;
	
	/*
	 * The fetchLeaveBudget method is used to fetch the Employees Leave Budget from the Leave_History table. This operation is generally used when the employee has previously 
	 * applied for leave. This method uses prepared statement to set the leaveId for fetching the record. 
	 * @param LeaveID
	 * @return Leave Budget of the employee
	 */
	@Override
	public int fetchLeaveBudget(int lId) throws ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchLeaveBudget Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchLeaveBudget_QRY);
		pst.setInt(1, lId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		emsLogger.info("In EmployeeDaoImpl fetchLeaveBudget Function: returning results");
		return result;
	}
	
	/*
	 * The fetchLeaveDuration method is used to fetch the remaining leave duration of the employee from the Leave_History table. This operation is generally used to obtain the leave duration
	 * of the applied leave of the employee for the Manager view of the application. And based on his selection of approval or rejection the leave_budget is updated in the table.
	 * @param LeaveID
	 * @return Leave Duration of the applied leave of the employee
	 */
	@Override
	public int fetchLeaveDuration(int lId) throws ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchLeaveDuration Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchLeaveDuration_QRY);
		pst.setInt(1, lId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		emsLogger.info("In EmployeeDaoImpl fetchLeaveDuration Function: returning results");
		return result;
	}
	
	/*
	 * The fetchInitialLeaveBudget method is used to fetch the Employees Leave Budget from the Leave_History table initially.
	 * @param Employee ID
	 * @return Initial Leave Budget of the new employee
	 */
	@Override
	public int fetchInitialLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchInitialLeaveBudget Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_fetchInitialLeaveDuration_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		int result = 0;
		while(rs.next()) {
			result = rs.getInt(1);
		}
		emsLogger.info("In EmployeeDaoImpl fetchInitialLeaveBudget Function: returning results");
		return result;
	}
	
	/*
	 * The newLeaveRequest method is used for the application of a new leave request. The leaveRecord object is sent to the method as an argument.
	 * The database is updated with the new leave request which the respective manager can view on his/her console.
	 * @param LeaveRecords Object
	 * @return True/False based on the application of the new Leave request
	 */
	@Override
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl newLeaveRequest Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_addLeaveRequest_QRY);
		pst.setString(1, leaveRecord.getEmpId());
		pst.setString(2, leaveRecord.getEmpName());
		pst.setInt(3, leaveRecord.getLeaveBalance());
		pst.setInt(4, leaveRecord.getNoOfDays());
		pst.setDate(5, Date.valueOf(leaveRecord.getFromDate()));
		pst.setDate(6, Date.valueOf(leaveRecord.getToDate()));
		pst.setString(7, leaveRecord.getStatus());
		int insertStatus = pst.executeUpdate();
		if(insertStatus>0){
			leaveRecord.setLeaveId(getLeaveId());
			return true;
		}
		emsLogger.info("In EmployeeDaoImpl newLeaveRequest Function: returning results");
		return false;
	}
	
	/*
	 * The getLeaveId method is used to fetch the leave Id of the leaves applied by the employee since it is auto-generated by a sequence.
	 * @return Leave Id for a new LeaveId
	 */
	private int getLeaveId() throws SQLException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl getLeaveId Function");
		int id=0;
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(QueryMapper.EMP_fetchLeaveId_QRY);			
		if(rs.next()){
			id = rs.getInt(1);
		}
		emsLogger.info("In EmployeeDaoImpl getLeaveId Function: returning results");
		return id;
	}
	
	/*
	 * The updateLeaveRequest method is used to update the leave Request of the employee based on the choice of the manager.
	 * It can be approved or rejected.
	 * @param LeaveID, updatedStatus, Remaining leaveBalance
	 * @return True/False based on the modification of the Leave request
	 */
	@Override
	public boolean updateLeaveRequest(int lId, String updatedStatus, int leaveBal) throws SQLException, ClassNotFoundException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl updateLeaveRequest Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MGR_updateleaveStatus_QRY);
		pst.setString(1, updatedStatus);
		pst.setInt(2, leaveBal);
		pst.setInt(3, lId);
		int updateStatus = pst.executeUpdate(); 
		if(updateStatus>0) {
			emsLogger.info("In EmployeeDaoImpl updateLeaveRequest Function: returning results");
			return true;
		}
		else {
			emsLogger.info("In EmployeeDaoImpl updateLeaveRequest Function: returning results");
			return false;
		}
	}
	
	/*
	 * The fetchAllLeaveRequests method is used to fetch all the Employees Leave Requests for the Manager from the Leave_History table. 
	 * @param Manager Id
	 * @return The ArrayList of all the new leaves that the manager has received 
	 */
	@Override
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String mngrId) throws SQLException, ClassNotFoundException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchAllLeaveRequests Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.MGR_fetchAllLeaveRequest_QRY);
		pst.setString(1, mngrId);
		rs = pst.executeQuery();
		ArrayList<LeaveRecords> list = new ArrayList<LeaveRecords>();
		LeaveRecords lr = null;
		while(rs.next()) {
			lr = new LeaveRecords(); 
			lr.setLeaveId(rs.getInt(1));
			lr.setEmpId(rs.getString(2));
			lr.setEmpName(rs.getString(3));
			lr.setLeaveBalance(rs.getInt(4));
			lr.setNoOfDays(rs.getInt(5));
			lr.setFromDate(rs.getDate(6).toLocalDate());
			lr.setToDate(rs.getDate(7).toLocalDate());
			lr.setStatus(rs.getString(8));
			list.add(lr);
		}
		emsLogger.info("In EmployeeDaoImpl fetchAllLeaveRequests Function: returning results");
		return list;
	}
	
	/*
	 * The findEmployeePastLeaves method is used to check whether the employee has ever applied for leave or not. If not, the initial leave budget will be 12 otherwise it will be
	 * fetched from the Leave_History table.
	 * @param Employee Id
	 * @return True/False based on whether the employee has applied for leave or not in the past
	 */
	@Override
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl findEmployeePastLeaves Function");
		con = DBUtil.getCon();
		pst = con.prepareStatement(QueryMapper.EMP_leavehistory_QRY);
		pst.setString(1, empId);
		rs = pst.executeQuery();
		if(rs.next()) {
			emsLogger.info("In EmployeeDaoImpl findEmployeePastLeaves Function: returning results");
			return true;
		}
		else{
			emsLogger.info("In EmployeeDaoImpl findEmployeePastLeaves Function: returning results");
			return false;
		}
	}
	
	/*
	 * The fetchPreviousRequests method is used to fetch the Employees Past Leave Budget from the Leave_History table. This operation is generally used when the employee wants to
	 * see the status of the previously applied leave Requests.
	 * @param Employee Id
	 * @return The ArrayList of all the past leaves for the particular employee 
	 */
	@Override
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchPreviousRequests Function");
		ArrayList<LeaveRecords> list = null;
		try {
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.EMP_previousleavehistory_QRY);
			pst.setString(1, empId);
			rs = pst.executeQuery();
			list = new ArrayList<LeaveRecords>();
			LeaveRecords lr = null;
			while(rs.next()) {
				lr = new LeaveRecords(); 
				lr.setLeaveId(rs.getInt(1));
				lr.setEmpId(rs.getString(2));
				lr.setEmpName(rs.getString(3));
				lr.setLeaveBalance(rs.getInt(4));
				lr.setNoOfDays(rs.getInt(5));
				lr.setFromDate(rs.getDate(6).toLocalDate());
				lr.setToDate(rs.getDate(7).toLocalDate());
				lr.setStatus(rs.getString(8));
				list.add(lr);
			}
		} catch (Exception e) {
			emsLogger.error(e.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl fetchPreviousRequests Function: returning results");
		return list;
	}
	
	/* 
	 * The searchEmployeeById method is used to search employees on the basis of their unique id.
	 * @param Employee Id
	 * @return The employee object with the id same as the entered id
	*/	
	@Override
	public Employee searchEmployeeById(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl searchEmployeeById Function");
		con = DBUtil.getCon();
		Employee emp = null;
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Id_QRY);
			pst.setString(1,id);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn=rs.getString(2);
				String ln=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn,ln,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
			}
		} catch (Exception e) {
			emsLogger.error(e.getMessage());
			throw new EmployeeException("DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl searchEmployeeById Function: returning results");
		return emp;
	}
	
	/* 
	 * The searchEmployeeByFirstName method is used to search employees on the basis of their first names.
	 * @param Employee's first name 
	 * @return The Array List of employees with the first name same as the entered first name
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl searchEmployeeByFirstName Function");
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Fn_QRY);
			pst.setString(1,fn);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e) {
			emsLogger.error(e.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl searchEmployeeByFirstName Function: returning results");
		return list;
	}
	
	/* 
	 * The searchEmployeeByLastName method is used to search employees on the basis of their last names.
	 * @param Employee's last name 
	 * @return The Array List of employees with the last name same as the entered last name
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByLastName(String ln) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchLeaveBudget Function");
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Ln_QRY);
			pst.setString(1,ln);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e) {
			emsLogger.error(e.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		return list;
	}
	
	/* 
	 * The searchEmployeeByDeptId method is used to search employees on the basis of their department id.
	 * @param Employee's department id
	 * @return The Array List of employees with the department id same as the entered department id.
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByDeptId(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl searchEmployeeByDeptId Function");
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_DepId_QRY);
			pst.setInt(1,id);
			rs=pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e1) {
			emsLogger.error(e1.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl searchEmployeeByDeptId Function: returning results");
		return list;
	}
	
	/* 
	 * The searchEmployeeByGrade method is used to search employees on the basis of their grade.
	 * @param Employee's grade
	 * @return The Array List of employees with the grade same as the entered grade
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByGrade(String grade) throws EmployeeException, ClassNotFoundException, SQLException, IOException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl searchEmployeeByGrade Function");
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_Grade_QRY);
			pst.setString(1,grade);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade1=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade1,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e1) {
			emsLogger.error(e1.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl searchEmployeeByGrade Function: returning results");
		return list;
	}
	
	/* 
	 * The searchEmployeeByMaritalStatus method is used to search employees on the basis of their Marital Status.
	 * @param Employee's Marital Status
	 * @return The Array List of employees with the Marital Status same as the entered Marital Status
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl searchEmployeeByMaritalStatus Function");
		con = DBUtil.getCon();
		Employee emp = null;
		ArrayList<Employee> list=new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(QueryMapper.SEARCH_MS_QRY);
			pst.setString(1,ms);
			rs = pst.executeQuery();
			while(rs.next())
			{
				String id1=rs.getString(1);	
				String fn1=rs.getString(2);
				String ln1=rs.getString(3);
				LocalDate dob=rs.getDate(4).toLocalDate();
				LocalDate doj=rs.getDate(5).toLocalDate();
				int deptid=rs.getInt(6);
				String grade1=rs.getString(7);
				String desg=rs.getString(8);
				int basic=rs.getInt(9);
				String gender=rs.getString(10);
				String marstatus=rs.getString(11);
				String addr=rs.getString(12);
				Long contactno=rs.getLong(13);
				String mgrid=rs.getString(14);
				emp = new Employee(id1,fn1,ln1,dob,doj,deptid,grade1,desg,basic,gender,marstatus,addr,contactno,mgrid);
				list.add(emp);
			}
		} catch (Exception e1) {
			emsLogger.error(e1.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl searchEmployeeByMaritalStatus Function: returning results");
		return list;
	}
	@Override
	public ArrayList<LeaveRecords> fetchPastLeaveDates(String empId) throws EmployeeException {
		emsLogger = Logger.getLogger(EmployeeDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
		emsLogger.debug("In EmployeeDaoImpl fetchPastLeaveDates Function");
		ArrayList<LeaveRecords> list = null;
		try {
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.EMP_fetchPreviousLeaveDates_QRY);
			pst.setString(1, empId);
			rs = pst.executeQuery();
			list = new ArrayList<LeaveRecords>();
			LeaveRecords lr = null;
			while(rs.next()) {
				lr = new LeaveRecords(); 
				lr.setLeaveId(rs.getInt(1));
				lr.setEmpId(rs.getString(2));
				lr.setEmpName(rs.getString(3));
				lr.setLeaveBalance(rs.getInt(4));
				lr.setNoOfDays(rs.getInt(5));
				lr.setFromDate(rs.getDate(6).toLocalDate());
				lr.setToDate(rs.getDate(7).toLocalDate());
				lr.setStatus(rs.getString(8));
				list.add(lr);
			}
		} catch (Exception e) {
			emsLogger.error(e.getMessage());
			throw new EmployeeException("Employee DAO Error");
		}
		emsLogger.info("In EmployeeDaoImpl fetchPastLeaveDates Function: returning results");
		return list;
	}
}
