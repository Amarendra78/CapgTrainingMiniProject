//This is an Login Interface(DAO level) which contains all the methods that are needed for performing Login Operations. It interacts with the database.

package com.cg.ems.dao;

import java.sql.SQLException;

import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;

public interface LoginDao {
	
	public String EmployeeType(UserMaster um) throws SQLException, EmployeeException;

}
