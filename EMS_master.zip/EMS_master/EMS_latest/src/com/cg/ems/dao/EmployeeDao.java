//This is an Employee Interface(DAO level) which contains all the methods that are needed for performing Employee Operations. It interacts with the database.

package com.cg.ems.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;

public interface EmployeeDao {
	
	public Employee searchEmployeeById(String id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> searchEmployeeByLastName(String ln) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> searchEmployeeByDeptId(int id) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> searchEmployeeByGrade(String grade) throws EmployeeException, ClassNotFoundException, SQLException, IOException;
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) throws ClassNotFoundException, SQLException, IOException, EmployeeException;
	public int fetchLeaveDuration(int lId) throws ClassNotFoundException, SQLException, IOException;
	public int fetchInitialLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException;
	public int fetchLeaveBudget(int lId) throws ClassNotFoundException, SQLException, IOException;
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException;
	public boolean updateLeaveRequest(int lId, String updatedStatus, int leaveBal) throws SQLException, ClassNotFoundException, IOException;
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String mngrId) throws SQLException, ClassNotFoundException, IOException;
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException;
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException;
	public ArrayList<LeaveRecords> fetchPastLeaveDates(String empId) throws EmployeeException;
}
