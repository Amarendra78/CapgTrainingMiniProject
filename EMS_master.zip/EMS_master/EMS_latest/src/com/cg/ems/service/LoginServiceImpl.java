//This is the implementation of the LoginService interface. The methods are overridden to interact with the DAO layer and return appropriate results.

package com.cg.ems.service;
import java.io.IOException;
import java.sql.SQLException;

import com.cg.ems.dao.LoginDao;
import com.cg.ems.dao.LoginDaoImpl;
import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;
/*
 * In the class LoginServiceImpl, a LoginDao object is created which is instantiated with LoginDaoImpl.
 * This object is used to fetch result from the DAO operation and return it to the UI.
 */
public class LoginServiceImpl implements LoginService {
	LoginDao loginDao;
  
	public LoginServiceImpl() throws ClassNotFoundException, SQLException, IOException{	
		loginDao = new LoginDaoImpl();
	}
	/*
	 * This function will return a String which is returned by EmployeeType method of LoginDaoImpl class to Main class
	 */
	@Override
	public String EmployeeType(UserMaster um) throws SQLException, EmployeeException {	
		return loginDao.EmployeeType(um);
	}

}
