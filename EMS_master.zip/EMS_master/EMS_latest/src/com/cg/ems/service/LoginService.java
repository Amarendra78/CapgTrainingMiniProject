//This is an Login Interface(Service level) which contains all the methods that are needed for performing Login Operations. It connects the DAO to the UI part of the application.

package com.cg.ems.service;

import java.sql.SQLException;

import com.cg.ems.dto.UserMaster;
import com.cg.ems.exception.EmployeeException;

public interface LoginService {
	
	public String EmployeeType(UserMaster um) throws SQLException, EmployeeException;
}
