//This is the implementation of the EmployeeService interface. The methods are overridden to interact with the DAO layer and return appropriate results.

package com.cg.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.LeaveRecords;
import com.cg.ems.exception.EmployeeException;
/*
 * In the class EmployeeServiceImpl, a EmployeeDao object is created which is instantiated with EmployeeDaoImpl.
 * This object is used to fetch result from the DAO operation and return it to the UI.
 */
public class EmployeeServiceImpl implements EmployeeService
{	EmployeeDao empDao = null;	
	public EmployeeServiceImpl() {
		empDao = new EmployeeDaoImpl();
	}
	/*
	 * @param LeaveID
	 * @return The Leave Budget of the employee for that request 
	 */
	@Override
	public int fetchLeaveBudget(int lId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchLeaveBudget(lId);
	}
	/*
	 * @param LeaveRecords Object
	 * @return True/False based on the application of the leave 
	 */
	@Override
	public boolean newLeaveRequest(LeaveRecords leaveRecord) throws ClassNotFoundException, SQLException, IOException {
		return empDao.newLeaveRequest(leaveRecord);
	}
	/*
	 * @param LeaveID, newStatus, leave Balance remaining
	 * @return True/False based on the modification of the leave request
	 */
	@Override
	public boolean updateLeaveRequest(int lId, String updatedStatus, int leaveBal) throws ClassNotFoundException, SQLException, IOException {
		return empDao.updateLeaveRequest(lId,updatedStatus,leaveBal);
	}
	/*
	 * @param Manager Id
	 * @return The ArrayList of all the new leaves that the manager has received 
	 */
	@Override
	public ArrayList<LeaveRecords> fetchAllLeaveRequests(String mngrId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchAllLeaveRequests(mngrId);
	}
	/*
	 * @param Employee Id
	 * @return True/False based on whether the employee has applied for leave or not in the past
	 */
	@Override
	public boolean findEmployeePastLeaves(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.findEmployeePastLeaves(empId);
	}
	/*
	 * @param Employee Id
	 * @return The ArrayList of all the past leaves for the particular employee 
	 */
	@Override
	public ArrayList<LeaveRecords> fetchPreviousRequests(String empId) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		return empDao.fetchPreviousRequests(empId);
	}
	/*
	 * @param Employee Id
	 * @return The employee object with the id same as the entered id 
	 */
	@Override
	public Employee searchEmployeeById(String id) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeById(id);
	}
	/*
	 * @param Employee First Name
	 * @return The ArrayList of employee objects with the firstName same as the entered name
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByFirstName(String fn) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByFirstName(fn);
	}
	/*
	 * @param Employee Second Name
	 * @return The ArrayList of employee objects with the lastName same as the entered name
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByLastName(String ln) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByLastName(ln);
	}
	/*
	 * @param Integer Department Id
	 * @return The ArrayList of employee objects who are in the entered deptId
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByDeptId(int id) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByDeptId(id);
	}
	/*
	 * @param String Grade
	 * @return The ArrayList of employee objects who have the grade as entered
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByGrade(String grade) throws ClassNotFoundException, EmployeeException, SQLException, IOException {
		return empDao.searchEmployeeByGrade(grade);
	}
	/*
	 * @param String Marital Status
	 * @return The ArrayList of employee objects who have the marital status as entered
	 */
	@Override
	public ArrayList<Employee> searchEmployeeByMaritalStatus(String ms) throws ClassNotFoundException, SQLException, IOException, EmployeeException {
		return empDao.searchEmployeeByMaritalStatus(ms);
	}
	/*
	 * @param Leave Id
	 * @return The Previous Leave Duration of the employee 
	 */
	@Override
	public int fetchLeaveDuration(int lId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchLeaveDuration(lId);
	}
	/*
	 * @param String employee Id
	 * @return The initial leaveBudget of the employee. 
	 */
	@Override
	public int fetchInitialLeaveBudget(String empId) throws ClassNotFoundException, SQLException, IOException {
		return empDao.fetchInitialLeaveBudget(empId);
	}
	@Override
	public ArrayList<LeaveRecords> fetchPastLeaveDates(String empId) throws EmployeeException {
		return empDao.fetchPastLeaveDates(empId);
	}

	
}
